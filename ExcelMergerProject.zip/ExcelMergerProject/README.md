﻿# ExcelMerger Portable

Программа для объединения Excel файлов в один.

## Как получить EXE

1. Создай новый репозиторий на GitHub.
2. Закинь туда папку `ExcelMerger` и `.github/workflows/publish-windows.yml`.
3. Перейди во вкладку Actions → запусти workflow.
4. В "Artifacts" появится zip с `ExcelMerger.exe`.
